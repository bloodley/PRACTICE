<?php

$host = 'localhost';
$database = 'ev-anders_alexandragasay';
$user = '046855410_alexan';
$pass = 'pyb83thghp2';
$dsn = "mysql:host=$host;dbname=$database;";
$options = array(
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
);

$pdo = new PDO($dsn, $user, $pass, $options);



function read_db($table_name) {
    global $pdo;
    $stmt = $pdo->query('SELECT * FROM '.$table_name.'');
    $data = $stmt->fetchAll();
    return $data;
} // Чтение БД


$news = read_db(post);

if(count($news) > 0){

    /// Проверяем на авторизацию
    $accounts = read_db('users');
    $c_acc = count($accounts);

    $yes = '';
    $x = 0;
    while ($x < $c_acc) {
        if ($accounts[$x]['session'] == $_COOKIE['sessionAcc']) {
            $userData = $accounts[$x];
            $yes = 1;
        }
        $x++;
    }


    $r = 0;
    while ($r < count($news)){
        $id_user_post = $news[$r]['id_create'] - 1;
        echo '

                <div class="col-lg-4">
                <div class="card mt-4">
                    <div class="card-header">Опубликовал: '.$accounts[$id_user_post]['name'].'</div>
                    <div class="card-body">
                        <h5 class="card-title">'.$news[$r]['title'].'</h5>
                        <p class="card-text">'.$news[$r]['main'].'</p>
                        ';
        if($news[$r]['id_create'] == $userData['id']){
            echo '


<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal_'.$r.'">
  Редактировать
</button>
<div class="modal fade" id="exampleModal_'.$r.'" tabindex="-1" aria-labelledby="exampleModalLabel_'.$r.'" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel_'.$r.'">Редактировать пост</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="card-body text-primary">
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Заголовок</label>
                            <input type="email" class="form-control" id="edit_title_'.$r.'" placeholder="Заголовок вашего поста" value="'.$news[$r]['title'].'">
                        </div>
                        <div class="mb-3">
                            <label for="exampleFormControlTextarea1" class="form-label">Содержание поста</label>
                            <textarea class="form-control" id="edit_main_text_'.$r.'" rows="3">'.$news[$r]['main'].'</textarea>
                        </div>

                        <button type="submit" class="btn btn-primary mb-3" onclick="edit(\'edit_title_'.$r.'\',\'edit_main_text_'.$r.'\',\''.$news[$r]['id'].'\')" data-bs-dismiss="modal">Сохранить</button>
                    </div>   
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
      </div>
    </div>
  </div>
</div>
';}
        echo'
                        <p class="card-text mt-1"><small class="text-muted">'.$news[$r]['time'].'</small></p>
                     </div>
                </div></div>
                ';
        $r++;
    }
}else{
    echo '
                
                <div class="col-lg-4">
                <div class="card">
                  <div class="card-header">
                    Оповещение
                  </div>
                  <div class="card-body">
                    <blockquote class="blockquote mb-0">
                      <p>Пока нет ни одного поста будте первыми</p>
                    </blockquote>
                  </div>
                  </div></div>


';
}