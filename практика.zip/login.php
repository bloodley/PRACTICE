<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Авторизация</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="signin.css" rel="stylesheet">
    <script src="js/jquery-3.5.0.js"></script>
</head>
<body class="text-center">

<div class="container mt-5">
    <div class="row">
        <div class="col-lg-4"></div>
        <div class="col-lg-4">
            <main class="form-signin">
                <div>
                    <h1 class="h3 mb-3 fw-normal">Авторизация</h1>
                    <div class="form-floating mt-5">
                        <input type="email" class="form-control" id="input-email" placeholder="name@example.com">
                        <label for="floatingInput">Email</label>
                    </div>
                    <div class="form-floating mt-5">
                        <input type="password" class="form-control" id="input-password" placeholder="Пароль">
                        <label for="floatingPassword">Пароль</label>
                    </div>

                    <button class="w-100 btn btn-lg btn-primary mt-5 mb-5" onclick="auth()" type="submit">Войти</button>
                    <a href="registration.php">Регистрация</a>
                    <p class="mt-5 mb-3 text-muted">&copy; Alexandra_Fedotova 2021</p>
                </div>
            </main>
        </div>
        <div class="col-lg-4"></div>
    </div>
</div>



<script>
    function validateEmail(email) {
        var pattern  = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return pattern .test(email);
    }

    function auth() {
        email = document.getElementById('input-email').value;
        if(validateEmail(email)){
            password = document.getElementById('input-password').value;
            if(password){
                hash_pass = sha256(password);
                $.post(
                    "lib/auth.php",
                    {
                        email: email,
                        hash_pass: hash_pass,
                    },
                    onAjaxSuccess
                );

                function onAjaxSuccess(data) {
                    if(data === 'ok'){
                        window.location.href = 'index.php';
                    }else{
                        alert(data);
                    }
                }
            }else{
                alert('Пароль слабый или не указан');
            }
        }else{
            alert('Email не указан или написан не верно');
        }
    }
</script>


<script src="js/sha256.min.js"></script>
</body>
</html>
