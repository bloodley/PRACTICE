<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Регистрация</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="signin.css" rel="stylesheet">
    <script src="js/jquery-3.5.0.js"></script>
</head>
<body class="text-center">

<div class="container mt-5">
    <div class="row">
        <div class="col-lg-4"></div>
        <div class="col-lg-4">
            <main class="form-signin">
                <div>
                    <h1 class="h3 mb-3 fw-normal">Регистрация</h1>

                    <div class="form-floating mt-5">
                        <input type="email" class="form-control" id="input-email" placeholder="name@example.com">
                        <label for="floatingInput">Email</label>
                    </div>
                    <div class="form-floating mt-5">
                        <input type="text" class="form-control" id="input-name" placeholder="Имя">
                        <label for="floatingPassword">Имя</label>
                    </div>

                    <div class="form-floating mt-5">
                        <input type="number" class="form-control" id="number" placeholder="Номер телефона">
                        <label for="floatingPassword">Номер телефона</label>
                    </div>

                    <div class="form-floating mt-5">
                        <input type="password" class="form-control" id="input-password" placeholder="Пароль">
                        <label for="floatingPassword">Пароль</label>
                    </div>

                    <div class="form-floating mt-5">
                        <input type="password" class="form-control" id="input-password-confirm" placeholder="Подтверждение пароля">
                        <label for="floatingPassword">Подтверждение пароля</label>
                    </div>



                    <button onclick="register()" class="w-100 btn btn-lg btn-primary mt-5 mb-5" type="submit">Регистрация</button>
                    <a href="index.php">Авторизация</a>
                    <p class="mt-5 mb-3 text-muted">&copy; Alexandra_Gasay 2021</p>
                </div>
            </main>
        </div>
        <div class="col-lg-4"></div>
    </div>
</div>



<script>
    function isCorrectFIO(fio) {
        if (!fio) {
            return false;
        }
        var fioA = fio.split(' ');
        if (fioA.length !== 2) {
            return false;
        }
        for (var i = 0; i < 3; i++) {
            if (/[^-А-ЯA-Z\x27а-яa-z]/.test(fioA[i])) {
                return false;
            }
        }
        return true;
    }
    function validateEmail(email) {
        var pattern  = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return pattern .test(email);
    }
    function class_pass(){
        var password = document.getElementById('input-password').value;

        if(password.search(/[А-яЁё]/) === -1){
            var s_letters = "qwertyuiopasdfghjklzxcvbnm";
            var b_letters = "QWERTYUIOPLKJHGFDSAZXCVBNM";
            var digits = "0123456789";
            var specials = "!@#$%^&*()_-+=\|/.,:;[]{}";
            var is_s = false;
            var is_b = false;
            var is_d = false;
            var is_sp = false;
            for (var i = 0; i < password.length; i++) {
                if (!is_s && s_letters.indexOf(password[i]) != -1) is_s = true;
                else if (!is_b && b_letters.indexOf(password[i]) != -1) is_b = true;
                else if (!is_d && digits.indexOf(password[i]) != -1) is_d = true;
                else if (!is_sp && specials.indexOf(password[i]) != -1) is_sp = true;
            }
            var rating = 0;
            var text = "";
            if (is_s) rating++;
            if (is_b) rating++;
            if (is_d) rating++;
            if (is_sp) rating++;
            if (password.length < 6 && rating < 3) text = '1';
            else if (password.length < 6 && rating >= 3) text = '2';
            else if (password.length >= 8 && rating < 3) text = '2';
            else if (password.length >= 8 && rating >= 3) text = '3';
            else if (password.length >= 6 && rating == 1) text = '1';
            else if (password.length >= 6 && rating > 1 && rating < 4) text = '2';
            else if (password.length >= 6 && rating == 4) text = '3';
            return text;
        }else{
            return 1;
        }
    }

    function register() {
        user_name = document.getElementById('input-name').value;
        if (isCorrectFIO(user_name)){
            email = document.getElementById('input-email').value;
            if(validateEmail(email)) {
                number = document.getElementById('number').value;
                if(number){
                    if(class_pass() > 1){
                        password = document.getElementById('input-password').value;
                        confirm = document.getElementById('input-password-confirm').value;
                        if(password == confirm){
                            hash_pass = sha256(password);
                            number = document.getElementById('number').value;
                            $.post(
                                "lib/reg.php",
                                {
                                    user_name: user_name,
                                    email: email,
                                    hash_pass: hash_pass,
                                    number: number,
                                },
                                onAjaxSuccess
                            );
                            function onAjaxSuccess(data) {
                                if(data === 'ok'){
                                    window.location.href = 'index.php';
                                }else{
                                    alert(data);
                                }
                            }
                        }else{
                            alert('Пароли не совпадают');
                        }
                    }else{
                        alert('Пароль слабый или не указан');
                    }
                }else{
                    alert('Укажите номер телефона');
                }
            }else{
                alert('Email не указан или написан не верно');
            }
        }else{
            alert('Имя не указано или написано не верно');
        }
    }
</script>


<script src="js/sha256.min.js"></script>
</body>
</html>
