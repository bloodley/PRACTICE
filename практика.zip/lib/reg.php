<?php

$host = 'localhost';
$database = 'ev-anders_alexandragasay';
$user = '046855410_alexan';
$pass = 'pyb83thghp2';
$dsn = "mysql:host=$host;dbname=$database;";
$options = array(
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
);

$pdo = new PDO($dsn, $user, $pass, $options);



function read_db($table_name) {
    global $pdo;
    $stmt = $pdo->query('SELECT * FROM '.$table_name.'');
    $data = $stmt->fetchAll();
    return $data;
} // Чтение БД


if(preg_match('~[^а-яёА-ЯЁ ]~u', $_POST['user_name'])) { // Проверем Имя Фамилию
    echo 'Имя указано не верно';
}else{
    if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) { // Проверяем почту

        /// Регистрируем пользователя
        $accounts = read_db('users');
        $c_acc = count($accounts);

        $no = '';
        $x = 0;
        while ($x < $c_acc){
            if($accounts[$x]['email'] == $_POST['email']){
                $no = 1;
            }
            $x++;
        } /// Проверяем есть ли такая почта

        if(!$no){

            $id = '';
            $user_name = $_POST['user_name'];
            $email = $_POST['email'];
            $number = $_POST['number'];
            $hash_pass = $_POST['hash_pass'];
            $time = microtime();

            $str_session = $hash_pass.''.$email.''.$time; // Строка для сессии авторизации
            $session = hash('sha256', $str_session);

            $inTwoMonths = 60 * 60 * 24 * 60 + time();
            setcookie('sessionAcc', $session, $inTwoMonths, '/', 'wildquiz.ru');

            $pdo->exec("INSERT INTO users (id, email, name, number, pass, session) VALUES ('{$id}', '{$email}', '{$user_name}', '{$number}', '{$hash_pass}', '{$session}')");
            $conn = null;
            echo 'ok';


        }else{
            echo 'Пользователь с таким почтовым ящиком уже есть';
        }
    }else{
        echo 'Почтовый ящик указан не верно';
    }
}