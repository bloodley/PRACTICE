<?php


$host = 'localhost';
$database = 'ev-anders_alexandragasay';
$user = '046855410_alexan';
$pass = 'pyb83thghp2';
$dsn = "mysql:host=$host;dbname=$database;";
$options = array(
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
);

$pdo = new PDO($dsn, $user, $pass, $options);


function update($tableName,$columnName,$id,$value){
    global $pdo;
    $idn = 'id';
    $sql = 'UPDATE '.$tableName.' SET '.$columnName.'= "'.$value.'" WHERE '.$idn.'='.$id.'';
    $pdo->prepare($sql)->execute([$columnName, $idn]);
}// обновление любой отдельной ячейки пример  $tableName = 'users' , $columnName = 'step' , $id = '40' , $value = '000'


update('post','title',$_POST['id_post'],$_POST['title']);
update('post','main',$_POST['id_post'],$_POST['main_text']);


echo 'ok';



