<?php
$host = 'localhost';
$database = 'ev-anders_alexandragasay';
$user = '046855410_alexan';
$pass = 'pyb83thghp2';
$dsn = "mysql:host=$host;dbname=$database;";
$options = array(
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
);

$pdo = new PDO($dsn, $user, $pass, $options);


function update($tableName,$columnName,$id,$value){
    global $pdo;
    $idn = 'id';
    $sql = 'UPDATE '.$tableName.' SET '.$columnName.'= "'.$value.'" WHERE '.$idn.'='.$id.'';
    $pdo->prepare($sql)->execute([$columnName, $idn]);
}// обновление любой отдельной ячейки пример  $tableName = 'users' , $columnName = 'step' , $id = '40' , $value = '000'

// email
// hash_pass

function authUser($email, $hash_sum){
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = '$email'");
    $stmt->execute(['email' => $email]);
    $data = $stmt->fetch();
    if($data){
        if($data['pass'] == $hash_sum){ // Проверяем пароль

            // Всё подошло
            // Авторизовываем пользователя
            $time = microtime();
            $str_session = $hash_sum.''.$email.''.$time; // Строка для сессии авторизации
            $session = hash('sha256', $str_session);
            $inTwoMonths = 60 * 60 * 24 * 60 + time();
            setcookie('sessionAcc', $session, $inTwoMonths, '/', 'wildquiz.ru');

            update('users','session',$data['id'],$session);
            echo 'ok';
        }else{
            echo 'Пароль набран не верно';
        }
    }else{
        echo 'Email указан не верно';
    }
}


authUser($_POST['email'], $_POST['hash_pass']);