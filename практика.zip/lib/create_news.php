<?php

$host = 'localhost';
$database = 'ev-anders_alexandragasay';
$user = '046855410_alexan';
$pass = 'pyb83thghp2';
$dsn = "mysql:host=$host;dbname=$database;";
$options = array(
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
);

$pdo = new PDO($dsn, $user, $pass, $options);


function read_db($table_name) {
    global $pdo;
    $stmt = $pdo->query('SELECT * FROM '.$table_name.'');
    $data = $stmt->fetchAll();
    return $data;
} // Чтение БД



if($_POST['title']){
    if($_POST['main_text']){


        /// Проверяем на авторизацию и получаем id пользователя
        $accounts = read_db('users');
        $c_acc = count($accounts);

        $yes = '';
        $x = 0;
        while ($x < $c_acc) {
            if ($accounts[$x]['session'] == $_COOKIE['sessionAcc']) {
                $userData = $accounts[$x];
            }
            $x++;
        }


        if($userData['id']){
            $id = '';
            $title = $_POST['title'];
            $main= $_POST['main_text'];
            $id_create = $userData['id'];
            $time = date("m.d.y");

            $pdo->exec("INSERT INTO post (id, title, main, id_create, time) VALUES ('{$id}', '{$title}', '{$main}', '{$id_create}', '{$time}')");
            $conn = null;
            echo 'ok';
        }


    }else{
        echo 'Вы не написали пост';
    }
}else{
    echo 'Вы не написали заголовок.';
}