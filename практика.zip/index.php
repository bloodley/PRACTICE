<?php

$host = 'localhost';
$database = 'ev-anders_alexandragasay';
$user = '046855410_alexan';
$pass = 'pyb83thghp2';
$dsn = "mysql:host=$host;dbname=$database;";
$options = array(
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
);

$pdo = new PDO($dsn, $user, $pass, $options);



function read_db($table_name) {
    global $pdo;
    $stmt = $pdo->query('SELECT * FROM '.$table_name.'');
    $data = $stmt->fetchAll();
    return $data;
} // Чтение БД

// 79283733778


if($_COOKIE['sessionAcc']){

    /// Проверяем на авторизацию
    $accounts = read_db('users');
    $c_acc = count($accounts);

    $yes = '';
    $x = 0;
    while ($x < $c_acc) {
        if ($accounts[$x]['session'] == $_COOKIE['sessionAcc']) {
            $userData = $accounts[$x];
            $yes = 1;
        }
        $x++;
    }

    if($yes){
        include 'main.php';
    }else{
        // Сессия подделка отправляем вводить логин с паролем
        include 'login.php';
    }


}else{
    include 'login.php';
}
