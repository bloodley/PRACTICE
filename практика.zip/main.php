

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Личный кабинет с постами</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/jquery-3.5.0.js"></script>
</head>
<body>

<main>
    <header class="p-3 bg-dark text-white">
        <div class="container">
            <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
                <div class="text-end">
                    <button type="button" onclick="deleteAllCookies()" class="btn btn-warning">Выйти из аккаунта</button>
                </div>
            </div>
        </div>
    </header>



    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="mt-5 mb-5">Вы: <?=$userData['name']?></h2>
                <h1 class="mt-5 mb-5">Написать пост</h1>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4">
                <div class="card mb-3">
                    <div class="card-header">Написать пост</div>
                    <div class="card-body text-primary">
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Заголовок</label>
                            <input type="email" class="form-control" id="title" placeholder="Заголовок вашего поста">
                        </div>
                        <div class="mb-3">
                            <label for="exampleFormControlTextarea1" class="form-label">Содержание поста</label>
                            <textarea class="form-control" id="main_text" rows="3"></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary mb-3" onclick="newPost()">Опубликовать</button>
                    </div>
                </div>
            </div>
        </div>



        <div class="row">
            <div class="col-lg-12">
                <h1 class="mt-5 mb-5">Все посты</h1>
            </div>
        </div>
        <div class="row" id="all_news">
            <?


            $news = read_db(post);

            if(count($news) > 0){
                $r = 0;
                while ($r < count($news)){
                    $id_user_post = $news[$r]['id_create'] - 1;
                    echo '

                <div class="col-lg-4">
                    <div class="card mt-4">
                        <div class="card-header">Опубликовал: '.$accounts[$id_user_post]['name'].'</div>
                        <div class="card-body">
                            <h5 class="card-title">'.$news[$r]['title'].'</h5>
                            <p class="card-text">'.$news[$r]['main'].'</p>
                            ';
        if($news[$r]['id_create'] == $userData['id']){
            echo '


<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal_'.$r.'">
  Редактировать
</button>
<div class="modal fade" id="exampleModal_'.$r.'" tabindex="-1" aria-labelledby="exampleModalLabel_'.$r.'" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel_'.$r.'">Редактировать пост</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      
      
        <div class="card-body text-primary">
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Заголовок</label>
                            <input type="email" class="form-control" id="edit_title_'.$r.'" placeholder="Заголовок вашего поста" value="'.$news[$r]['title'].'">
                        </div>
                        <div class="mb-3">
                            <label for="exampleFormControlTextarea1" class="form-label">Содержание поста</label>
                            <textarea class="form-control" id="edit_main_text_'.$r.'" rows="3">'.$news[$r]['main'].'</textarea>
                        </div>

                        <button type="submit" class="btn btn-primary mb-3" onclick="edit(\'edit_title_'.$r.'\',\'edit_main_text_'.$r.'\',\''.$news[$r]['id'].'\')" data-bs-dismiss="modal">Сохранить</button>
                    </div>
                    
                    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
      </div>
    </div>
  </div>
</div>
';}
                            echo'
                            <p class="card-text mt-1"><small class="text-muted">'.$news[$r]['time'].'</small></p>
                        </div>
                    </div>
                </div>
                ';
                    $r++;
                }
            }else{
                echo '
                
                <div class="col-lg-4">
                <div class="card">
  <div class="card-header">
    Оповещение
  </div>
  <div class="card-body">
    <blockquote class="blockquote mb-0">
      <p>Пока нет ни одного поста будте первыми</p>
    </blockquote>
  </div>
</div></div>


';
            }

            ?>
        </div>
    </div>
</main>


<script>

    function edit(title_id,maintext_id,id_post){
        title = document.getElementById(title_id).value;
        maintext = document.getElementById(maintext_id).value;

        if(title){
            console.log(maintext);
            if(maintext){
                $.post(
                    "lib/edit_news.php",
                    {
                        title: title,
                        main_text: maintext,
                        id_post: id_post,
                    },
                    onAjaxSuccess
                );
                function onAjaxSuccess(data) {
                    console.log(data);
                    if(data === 'ok'){
                        get_all_post();
                        console.warn('reload news')
                    }else{
                        alert(data);
                    }
                }
            }else{
                alert('Вы не написали пост');
            }
        }else{
            alert('Вы не указали заголовок');
        }
    }


    function deleteAllCookies() {
        $.post(
            "lib/deleteAllCookies.php",
            {
                case: 'deleteAllCookies',
            },
            onAjaxSuccess
        );
        function onAjaxSuccess(data) {
            window.location.reload(true);
        }
    }


    function newPost(){
        title = document.getElementById('title').value;
        maintext = document.getElementById('main_text').value;

        if(title){
            console.log(maintext);
            if(maintext){
                $.post(
                    "lib/create_news.php",
                    {
                        title: title,
                        main_text: maintext,
                    },
                    onAjaxSuccess
                );
                function onAjaxSuccess(data) {
                    console.log(data);
                    if(data === 'ok'){
                        get_all_post();
                        console.warn('reload news')
                    }else{
                        alert(data);
                    }
                }
            }else{
                alert('Вы не написали пост');
            }
        }else{
            alert('Вы не указали заголовок');
        }
    }



    function get_all_post(){
        $.post(
            "all_post.php",
            {
                ok: 'ok',
            },
            onAjaxSuccess
        );
        function onAjaxSuccess(data) {
            document.getElementById('all_news').innerHTML = data;
        }
    }
</script>

<script src="bb/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="bb/docsearch.min.js"></script>
<script src="bb/docs.min.js"></script>

<script src="js/sha256.min.js"></script>
</body>
</html>
